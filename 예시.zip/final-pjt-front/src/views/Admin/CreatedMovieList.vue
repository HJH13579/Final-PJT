<template>
  <div>

  </div>
</template>

<script>
export default {
  name: 'CreatedMovieList',
}
</script>

<style>

</style>